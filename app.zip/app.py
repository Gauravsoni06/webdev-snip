from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

@app.route('/')
def compare():
    # Sample data for the dropdowns
    years = [2025, 2024, 2023]
    entity_years = ['Entity Year 1', 'Entity Year 2', 'Entity Year 3']
    run_types = ['Run Type 1', 'Run Type 2', 'Run Type 3']

    return render_template('compare.html', years=years, entity_years=entity_years, run_types=run_types)

@app.route('/submit', methods=['POST'])
def submit():
    # Process form data here
    return redirect(url_for('compare'))

if __name__ == '__main__':
    app.run(debug=True)
