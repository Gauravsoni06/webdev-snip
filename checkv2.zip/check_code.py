import pandas as pd
import numpy as np

def check_missing_values(df):
    """Check for missing values in the dataset"""
    try:
        missing_count = df.isnull().sum().sum()
        return 'FAIL' if missing_count > 0 else 'PASS'
    except:
        return 'FAIL'

def check_duplicate_rows(df):
    """Check for duplicate rows in the dataset"""
    try:
        duplicate_count = df.duplicated().sum()
        return 'FAIL' if duplicate_count > 0 else 'PASS'
    except:
        return 'FAIL'

def check_numeric_columns(df):
    """Check if numeric columns contain only numbers"""
    try:
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        for col in numeric_cols:
            if not pd.to_numeric(df[col], errors='coerce').notnull().all():
                return 'FAIL'
        return 'PASS'
    except:
        return 'FAIL'

def check_date_format(df):
    """Check if date columns are in correct format"""
    try:
        date_cols = df.select_dtypes(include=['datetime64']).columns
        for col in date_cols:
            if pd.to_datetime(df[col], errors='coerce').isnull().any():
                return 'FAIL'
        return 'PASS'
    except:
        return 'FAIL'

def check_string_length(df):
    """Check if string columns exceed maximum length"""
    try:
        string_cols = df.select_dtypes(include=['object']).columns
        max_length = 100  # Maximum allowed length
        for col in string_cols:
            if df[col].str.len().max() > max_length:
                return 'FAIL'
        return 'PASS'
    except:
        return 'FAIL'

# Dictionary mapping check IDs to their corresponding functions
CHECK_FUNCTIONS = {
    'CHK001': check_missing_values,
    'CHK002': check_duplicate_rows
}

def run_validation_checks(input_df, selected_checks, file_name=None):
    """
    Run selected validation checks on the input DataFrame
    
    Args:
        input_df: Input DataFrame to validate
        selected_checks: DataFrame containing selected checks with Check ID and Description
        file_name: Name of the input file being validated
    
    Returns:
        DataFrame with check results
    """
    results = []

    for _, check in selected_checks.iterrows():
        check_id = check['Check ID']
        if check_id in CHECK_FUNCTIONS:
            check_function = CHECK_FUNCTIONS[check_id]
            status = check_function(input_df)
            results.append({
                'File Name': file_name,
                'Check ID': check_id,
                'Check Description': check['Check Description'],
                'Status': status
            })

    return pd.DataFrame(results)