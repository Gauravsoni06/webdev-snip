from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QProgressBar
from PySide6.QtCore import Qt
from styles import *

class LoadingScreen(QWidget):
    def __init__(self):
        super().__init__()
        self.setFixedSize(300, 200)
        self.setWindowFlags(Qt.WindowStaysOnTopHint | Qt.FramelessWindowHint)
        self.setStyleSheet(f"background-color: {WHITE};")
        
        layout = QVBoxLayout()
        
        # Loading message
        self.message = QLabel("Running Validation Checks...")
        self.message.setStyleSheet("""
            color: #8E44AD;
            font-size: 16px;
            font-weight: bold;
            margin: 20px;
        """)
        self.message.setAlignment(Qt.AlignCenter)
        
        # Progress bar
        self.progress = QProgressBar()
        self.progress.setStyleSheet("""
            QProgressBar {
                border: 2px solid #8E44AD;
                border-radius: 5px;
                text-align: center;
                height: 25px;
            }
            QProgressBar::chunk {
                background-color: #8E44AD;
            }
        """)
        self.progress.setMinimum(0)
        self.progress.setMaximum(0)  # Infinite progress bar
        
        layout.addWidget(self.message)
        layout.addWidget(self.progress)
        self.setLayout(layout)
        
    def center_on_parent(self, parent):
        parent_geo = parent.geometry()
        x = parent_geo.x() + (parent_geo.width() - self.width()) // 2
        y = parent_geo.y() + (parent_geo.height() - self.height()) // 2
        self.move(x, y) 