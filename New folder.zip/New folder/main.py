import sys
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                              QTabWidget, QLabel, QHBoxLayout)
from PySide6.QtCore import Qt
from Load_file import LoadFileTab
from Load_checks import LoadChecksTab
from check_result import CheckResultTab
from styles import *

class ShazamApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("SHAZAM")
        self.setStyleSheet(f"""
            QMainWindow {{
                background-color: {BACKGROUND_COLOR};
            }}
            QTabWidget::pane {{
                border: none;
                background-color: {BACKGROUND_COLOR};
            }}
        """)

        # Set the application to full screen
        self.showFullScreen()

        # Main widget and layout
        main_widget = QWidget()
        self.main_layout = QVBoxLayout(main_widget)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.main_layout.setSpacing(0)

        # Title bar
        title_bar = QWidget()
        title_bar.setStyleSheet(TITLE_BAR_STYLE)
        title_layout = QHBoxLayout(title_bar)
        title_layout.setContentsMargins(0, 0, 0, 0)
        
        # Title label with lightning bolt emoji
        title_label = QLabel("⚡ SHAZAM")
        title_label.setStyleSheet(TITLE_LABEL_STYLE)
        title_label.setAlignment(Qt.AlignCenter)
        title_layout.addWidget(title_label)
        
        self.main_layout.addWidget(title_bar)

        # Content area
        content_widget = QWidget()
        content_layout = QVBoxLayout(content_widget)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(0)

        # Tab widget
        self.tabs = QTabWidget()
        self.tabs.setStyleSheet("""
            QTabWidget::pane {
                border: none;
                background-color: white;
            }
            QTabBar {
                border: none;
            }
            QTabBar::tab {
                background: transparent;
                border: none;
                padding: 0px;
                margin: 0px;
                height: 0px;
                width: 0px;
            }
        """)
        self.tabs.tabBar().hide()  # Hide the tab bar completely

        # Initialize tabs
        self.load_file_tab = LoadFileTab(self)
        self.load_checks_tab = LoadChecksTab(self)
        self.check_result_tab = CheckResultTab(self)

        # Add tabs (without labels since we're hiding them)
        self.tabs.addTab(self.load_file_tab, "")
        self.tabs.addTab(self.load_checks_tab, "")
        self.tabs.addTab(self.check_result_tab, "")

        content_layout.addWidget(self.tabs)
        self.main_layout.addWidget(content_widget)

        # Set the central widget
        self.setCentralWidget(main_widget)

        # Set minimum window size
        self.setMinimumSize(1000, 600)

    def closeEvent(self, event):
        """Handle application close event"""
        event.accept()

def main():
    app = QApplication(sys.argv)
    window = ShazamApp()
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()