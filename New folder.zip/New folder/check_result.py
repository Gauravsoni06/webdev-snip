from PySide6.QtWidgets import (QWidget, QVBoxLayout, QPushButton, QTableWidget, 
                              QTableWidgetItem, QLabel, QHBoxLayout, QHeaderView,
                              QFileDialog)
from PySide6.QtCore import Qt
import pandas as pd
import os
from styles import *
from check_code import run_validation_checks

class CheckResultTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.main_window = parent
        self.selected_checks = None
        self.input_df = None
        self.result_df = None
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(20)

        # Header
        header = QLabel("Checks Run Status")
        header.setStyleSheet(HEADER_STYLE)
        layout.addWidget(header)

        # Table
        self.table = QTableWidget()
        self.table.setStyleSheet(TABLE_STYLE)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setColumnCount(3)
        self.table.setHorizontalHeaderLabels(["Check ID", "Check Description", "Status"])
        
        # Set column sizes
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Fixed)
        self.table.setColumnWidth(0, 100)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Fixed)
        self.table.setColumnWidth(2, 100)
        
        layout.addWidget(self.table)

        # Task bar
        taskbar = QWidget()
        taskbar.setStyleSheet(TASKBAR_STYLE)
        taskbar_layout = QHBoxLayout(taskbar)
        taskbar_layout.setContentsMargins(20, 0, 20, 0)

        self.back_button = QPushButton("← Back")
        self.back_button.setStyleSheet(BUTTON_STYLE)
        self.back_button.clicked.connect(lambda: self.main_window.tabs.setCurrentIndex(1))
        taskbar_layout.addWidget(self.back_button)

        taskbar_layout.addStretch()

        self.save_button = QPushButton("Save Results")
        self.save_button.setStyleSheet(BUTTON_STYLE)
        self.save_button.clicked.connect(self.save_results)
        taskbar_layout.addWidget(self.save_button)

        layout.addWidget(taskbar)

    def run_checks(self):
        if self.selected_checks is not None and self.input_df is not None:
            self.result_df = run_validation_checks(self.input_df, self.selected_checks)
            self.display_results()

    def display_results(self):
        if self.result_df is not None:
            self.table.setRowCount(len(self.result_df))
            
            for i, row in self.result_df.iterrows():
                # Check ID
                id_item = QTableWidgetItem(str(row['Check ID']))
                id_item.setTextAlignment(Qt.AlignCenter)
                id_item.setFlags(id_item.flags() & ~Qt.ItemIsSelectable)
                self.table.setItem(i, 0, id_item)

                # Description
                desc_item = QTableWidgetItem(str(row['Check Description']))
                desc_item.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
                desc_item.setFlags(desc_item.flags() & ~Qt.ItemIsSelectable)
                self.table.setItem(i, 1, desc_item)

                # Status
                status_item = QTableWidgetItem(str(row['Status']))
                status_item.setTextAlignment(Qt.AlignCenter)
                status_item.setFlags(status_item.flags() & ~Qt.ItemIsSelectable)
                if row['Status'] == 'PASS':
                    status_item.setForeground(Qt.green)
                else:
                    status_item.setForeground(Qt.red)
                self.table.setItem(i, 2, status_item)

            # Adjust row heights
            for row in range(self.table.rowCount()):
                self.table.setRowHeight(row, 40)

    def save_results(self):
        if self.result_df is not None:
            # Get the original filename from load_file_tab
            original_filename = self.main_window.load_file_tab.file_path.text()
            suggested_name = f"{os.path.splitext(original_filename)[0]}_result.xlsx"
            
            file_name, _ = QFileDialog.getSaveFileName(
                self,
                "Save Results",
                suggested_name,
                "Excel Files (*.xlsx);;CSV Files (*.csv)"
            )
            
            if file_name:
                try:
                    if file_name.endswith('.xlsx'):
                        self.result_df.to_excel(file_name, index=False)
                    else:
                        self.result_df.to_csv(file_name, index=False)
                except Exception as e:
                    print(f"Error saving results: {e}")