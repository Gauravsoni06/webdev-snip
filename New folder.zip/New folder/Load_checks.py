from PySide6.QtWidgets import (QWidget, QVBoxLayout, QPushButton, QTableWidget, 
                              QTableWidgetItem, QLabel, QHBoxLayout, QCheckBox,
                              QHeaderView)
from PySide6.QtCore import Qt, Signal
import pandas as pd
from styles import *

class CheckBoxHeader(QHeaderView):
    checkbox_clicked = Signal(bool)

    def __init__(self, orientation, parent=None):
        super().__init__(orientation, parent)
        self.setSectionsClickable(True)
        
        # Create checkbox widget
        self.checkbox_widget = QWidget(self)
        self.checkbox_widget.setStyleSheet(f"""
            QWidget {{
                background-color: {PURPLE};  /* Set background color to match the header */
            }}
        """)
        
        layout = QHBoxLayout(self.checkbox_widget)
        layout.setAlignment(Qt.AlignCenter)
        layout.setContentsMargins(0, 0, 0, 0)
        
        self.checkbox = QCheckBox(self.checkbox_widget)
        self.checkbox.setStyleSheet("""
            QCheckBox {
                margin: 0px;
                padding: 0px;
            }
            QCheckBox::indicator {
                width: 20px;
                height: 20px;
                background-color: white;  /* Set background color for the checkbox */
                border: 2px solid white;  /* Border for the checkbox */
            }
            QCheckBox::indicator:unchecked {
                background-color: white;  /* Background color when unchecked */
            }
            QCheckBox::indicator:checked {
                background-color: #3366ff;  /* Green background when checked */
                border: 2px solid white;  /* Border for the checked state */
            }
        """)
        layout.addWidget(self.checkbox)
        
        self.checkbox.stateChanged.connect(self.checkbox_clicked.emit)
        self.sectionResized.connect(self.adjust_checkbox_position)

    def adjust_checkbox_position(self, logical_index, _, new_size):
        if logical_index == 2:  # Checkbox column
            self.checkbox_widget.setGeometry(
                self.sectionPosition(2),
                0,
                new_size,
                self.height()
            )

    def showEvent(self, event):
        super().showEvent(event)
        self.adjust_checkbox_position(2, 0, self.sectionSize(2))

class LoadChecksTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.main_window = parent
        self.input_df = None
        self.checks_df = None
        self.s_check = pd.DataFrame(columns=['Check ID', 'Check Description'])
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(20)

        # Header
        header = QLabel("Select Checks")
        header.setStyleSheet(HEADER_STYLE)
        layout.addWidget(header)

        # Table
        self.table = QTableWidget()
        self.table.setStyleSheet(TABLE_STYLE)
        
        # Create and set custom header
        header = CheckBoxHeader(Qt.Horizontal, self.table)
        self.table.setHorizontalHeader(header)
        header.checkbox_clicked.connect(self.on_select_all_changed)
        
        self.table.verticalHeader().setVisible(False)
        self.table.setColumnCount(3)
        self.table.setSelectionMode(QTableWidget.NoSelection)
        
        # Set headers and column sizes
        self.table.setHorizontalHeaderLabels(["Check ID", "Check Description", ""])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Fixed)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Fixed)
        self.table.setColumnWidth(0, 100)
        self.table.setColumnWidth(2, 100)
        
        layout.addWidget(self.table)

        # Task bar
        taskbar = QWidget()
        taskbar.setStyleSheet(TASKBAR_STYLE)
        taskbar_layout = QHBoxLayout(taskbar)
        taskbar_layout.setContentsMargins(20, 0, 20, 0)

        self.back_button = QPushButton("← Back")
        self.back_button.setStyleSheet(BUTTON_STYLE)
        self.back_button.clicked.connect(lambda: self.main_window.tabs.setCurrentIndex(0))
        taskbar_layout.addWidget(self.back_button)

        taskbar_layout.addStretch()

        self.run_button = QPushButton("Run Checks →")
        self.run_button.setStyleSheet(BUTTON_STYLE)
        self.run_button.clicked.connect(self.run_selected_checks)
        taskbar_layout.addWidget(self.run_button)

        layout.addWidget(taskbar)

    def on_select_all_changed(self, state):
        for row in range(self.table.rowCount()):
            checkbox_widget = self.table.cellWidget(row, 2)
            if checkbox_widget:
                checkbox = checkbox_widget.findChild(QCheckBox)
                if checkbox:
                    checkbox.setChecked(state)

    def load_checks_data(self):
        try:
            # Load checks from Excel file
            self.checks_df = pd.read_excel('check_list.xlsx')
            self.populate_table()
        except Exception as e:
            print(f"Error loading checks: {e}")

    def populate_table(self):
        if self.checks_df is not None:
            self.table.setRowCount(len(self.checks_df))
            
            for i, row in self.checks_df.iterrows():
                # Check ID
                id_item = QTableWidgetItem(str(row['Check ID']))
                id_item.setTextAlignment(Qt.AlignCenter)
                id_item.setFlags(id_item.flags() & ~Qt.ItemIsSelectable)
                self.table.setItem(i, 0, id_item)

                # Description
                desc_item = QTableWidgetItem(str(row['Check Description']))
                desc_item.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
                desc_item.setFlags(desc_item.flags() & ~Qt.ItemIsSelectable)
                self.table.setItem(i, 1, desc_item)

                # Checkbox
                checkbox_widget = QWidget()
                checkbox_layout = QHBoxLayout(checkbox_widget)
                checkbox_layout.setContentsMargins(0, 0, 0, 0)
                checkbox_layout.setAlignment(Qt.AlignCenter)
                
                checkbox = QCheckBox()
                checkbox.setStyleSheet("""
                    QCheckBox {
                        margin: 0;
                        padding: 0;
                    }
                    QCheckBox::indicator {
                        width: 20px;
                        height: 20px;
                    }
                """)
                checkbox_layout.addWidget(checkbox)
                
                self.table.setCellWidget(i, 2, checkbox_widget)

            # Adjust row heights
            for row in range(self.table.rowCount()):
                self.table.setRowHeight(row, 40)

    def run_selected_checks(self):
        selected_checks = []
        for row in range(self.table.rowCount()):
            checkbox_widget = self.table.cellWidget(row, 2)
            if checkbox_widget:
                checkbox = checkbox_widget.findChild(QCheckBox)
                if checkbox and checkbox.isChecked():
                    check_id = self.table.item(row, 0).text()
                    check_desc = self.table.item(row, 1).text()
                    selected_checks.append({
                        'Check ID': check_id,
                        'Check Description': check_desc
                    })
        
        self.s_check = pd.DataFrame(selected_checks)
        if not self.s_check.empty:
            self.main_window.check_result_tab.selected_checks = self.s_check
            self.main_window.check_result_tab.input_df = self.input_df
            self.main_window.check_result_tab.run_checks()
            self.main_window.tabs.setCurrentIndex(2)