from PySide6.QtWidgets import (QWidget, QVBoxLayout, QPushButton, QTableWidget, 
                              QTableWidgetItem, QFileDialog, QLabel, QHBoxLayout, 
                              QLineEdit, QHeaderView)
from PySide6.QtCore import Qt
import pandas as pd
import os
from styles import *

class LoadFileTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.main_window = parent
        self.df = None
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(20)

        # Header
        header = QLabel("Load File")
        header.setStyleSheet(HEADER_STYLE)
        layout.addWidget(header)

        # File selection row
        file_row = QHBoxLayout()
        
        self.load_button = QPushButton("Browse File")
        self.load_button.setStyleSheet(BROWSE_BUTTON_STYLE)
        self.load_button.clicked.connect(self.load_file)
        file_row.addWidget(self.load_button)

        self.file_path = QLineEdit()
        self.file_path.setStyleSheet(TEXTBOX_STYLE)
        self.file_path.setPlaceholderText("Select the compare file")
        self.file_path.setReadOnly(True)
        file_row.addWidget(self.file_path)

        layout.addLayout(file_row)

        # Table
        self.table = QTableWidget()
        self.table.setStyleSheet(TABLE_STYLE)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.table.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.table.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        layout.addWidget(self.table)

        # Task bar
        taskbar = QWidget()
        taskbar.setStyleSheet(TASKBAR_STYLE)
        taskbar_layout = QHBoxLayout(taskbar)
        taskbar_layout.setContentsMargins(20, 0, 20, 0)

        taskbar_layout.addStretch()
        
        self.next_button = QPushButton("Load Checks →")
        self.next_button.setStyleSheet(BUTTON_STYLE)
        self.next_button.clicked.connect(self.go_to_load_checks)
        self.next_button.setEnabled(False)
        taskbar_layout.addWidget(self.next_button)

        layout.addWidget(taskbar)

    def load_file(self):
        file_name, _ = QFileDialog.getOpenFileName(
            self,
            "Select Excel File",
            "",
            "Excel Files (*.xlsx *.xls)"
        )
        
        if file_name:
            try:
                # Specify the engine explicitly based on file extension
                if file_name.endswith('.xlsx'):
                    self.df = pd.read_excel(file_name, engine='openpyxl')
                else:
                    self.df = pd.read_excel(file_name, engine='xlrd')
                
                self.file_path.setText(os.path.basename(file_name))
                self.display_data(self.df.head(20))
                self.next_button.setEnabled(True)
                self.full_file_path = file_name
                
            except Exception as e:
                print(f"Error loading file: {e}")

    def display_data(self, data):
        self.table.setRowCount(len(data))
        self.table.setColumnCount(len(data.columns))
        self.table.setHorizontalHeaderLabels(data.columns)

        for i, row in enumerate(data.itertuples()):
            for j, value in enumerate(row[1:]):
                item = QTableWidgetItem(str(value))
                item.setTextAlignment(Qt.AlignCenter)
                item.setTextAlignment(Qt.AlignCenter | Qt.TextWordWrap)
                self.table.setItem(i, j, item)
        
        self.table.resizeRowsToContents()

    def go_to_load_checks(self):
        if self.df is not None:
            self.main_window.load_checks_tab.input_df = self.df
            self.main_window.load_checks_tab.load_checks_data()
            self.main_window.tabs.setCurrentIndex(1)