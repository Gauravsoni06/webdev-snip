# Colors
PURPLE = "#8E44AD"
LIGHT_PURPLE = "#9B59B6"
WHITE = "#FFFFFF"
BLACK = "#000000"
BACKGROUND_COLOR = WHITE

# Title Bar Style
TITLE_BAR_STYLE = f"""
    background-color: {PURPLE};
    min-height: 60px;
    max-height: 60px;
    padding: 0;
    margin: 0;
"""

TITLE_LABEL_STYLE = f"""
    color: {WHITE};
    font-size: 24px;
    font-weight: bold;
    padding: 0;
    margin: 0;
"""

# Header Style
HEADER_STYLE = f"""
    color: {PURPLE};
    font-size: 20px;
    font-weight: bold;
    padding: 15px;
    qproperty-alignment: AlignCenter;
"""

# Task Bar Style
TASKBAR_STYLE = f"""
    background-color: #F8F9FA;
    border: 1px solid {PURPLE};
    min-height: 40px;
    max-height: 40px;
    margin: 0 20px 20px 20px;
    padding: 0px;
"""

# Button Style
BUTTON_STYLE = f"""
    QPushButton {{
        background-color: {PURPLE};
        color: {WHITE};
        border: none;
        text-align: center;
        padding: 0px;
        min-width: 120px;
        max-width: 120px;
        min-height: 28px;
        max-height: 28px;
        font-weight: bold;
        border-radius: 3px;
    }}
    QPushButton:hover {{
        background-color: {LIGHT_PURPLE};
    }}
    QPushButton:disabled {{
        background-color: #CCCCCC;
    }}
"""

# Browse Button Style
BROWSE_BUTTON_STYLE = f"""
    QPushButton {{
        background-color: {PURPLE};
        color: {WHITE};
        border: none;
        padding: 5px 15px;
        min-width: 120px;
        font-weight: bold;
        border-radius: 3px;
        height: 28px;  /* Match the height of the text box */
    }}
    QPushButton:hover {{
        background-color: {LIGHT_PURPLE};
    }}
    QPushButton:disabled {{
        background-color: #CCCCCC;
    }}
"""

# Table Style
TABLE_STYLE = f"""
    QTableWidget {{
        background-color: {WHITE};
        gridline-color: #E0E0E0;
        border: 1px solid {PURPLE};
        color: {BLACK};
    }}
    QHeaderView::section {{
        background-color: {PURPLE};
        color: {WHITE};
        padding: 8px;
        font-weight: bold;
        border: none;
        white-space: pre-wrap;
    }}
    QTableWidget::item {{
        padding: 8px;
        border: 1px solid #E0E0E0;
        white-space: pre-wrap;
    }}
"""

# Text Box Style
TEXTBOX_STYLE = f"""
    QLineEdit {{
        border: 1px solid {PURPLE};
        padding: 5px;
        background: {WHITE};
        color: {BLACK};
        min-height: 25px;
    }}
    QLineEdit:disabled {{
        background: #F8F9FA;
    }}
"""